package Bundle::DBD::mysql;

use strict;
use warnings;

our $VERSION = '4.048';

1;

__END__

=pod

=head1 NAME

Bundle::DBD::mysql

=head1 DESCRIPTION

This package only exists for legacy reasons. Please use the L<DBD::mysql>
package instead.

=cut
